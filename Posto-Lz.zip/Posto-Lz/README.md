# Posto-Lz

Sistema simples em Python para controle de abastecimentos do **Posto Luizão**.

## Funcionalidades

- Cadastrar abastecimento
- Listar abastecimentos
- Buscar por ID ou nome do cliente
- Editar registro
- Excluir registro
- Gerar relatório simples

## Como executar

No terminal, dentro da pasta do projeto, execute:

```bash
python main.py
```

Ou, dependendo da instalação do Python:

```bash
python3 main.py
```

## Arquivos do projeto

- `main.py`: menu principal do sistema
- `crud.py`: funções de cadastrar, listar, buscar, editar, excluir e relatório
- `dados.py`: dados usados pelo sistema
- `utils.py`: funções auxiliares

## Observação

Os dados ficam salvos apenas enquanto o programa está aberto. Ao fechar o sistema, os registros cadastrados são apagados.
