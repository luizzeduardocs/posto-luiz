"""Arquivo responsável por guardar os dados do sistema."""

TIPOS_COMBUSTIVEL = ("gasolina", "etanol", "diesel")

abastecimentos = []

ids_usados = set()
